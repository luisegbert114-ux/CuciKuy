# CuciKuy Android — Prototype v1.1

Project Android starter untuk aplikasi jasa cuci kendaraan dan bersih rumah panggilan.

## Isi prototype
- Pemilihan layanan dan estimasi harga.
- Form pemesanan, alamat, tanggal, waktu, catatan, dan metode pembayaran.
- Pesanan demo tersimpan lokal di perangkat.
- Panel admin demo untuk melihat pesanan lokal dan mengubah status.
- Area teknisi demo.
- Tombol membuka Google Maps dengan alamat yang dimasukkan.
- Layar login/daftar rancangan.
- `supabase/schema.sql` sebagai rancangan awal database online.

## Membuat APK
1. Ekstrak ZIP.
2. Buka folder `CuciKuyAndroid` di Android Studio.
3. Pastikan komputer terhubung internet agar Gradle mengunduh Android Gradle Plugin.
4. Tunggu proses Gradle Sync.
5. Pilih **Build > Build APK(s)**.
6. Cari APK debug di `app/build/outputs/apk/debug/app-debug.apk`.
7. Pindahkan ke Android untuk pengujian. Instal hanya di perangkat sendiri/tepercaya.

## Batasan penting
Ini belum aplikasi produksi. Admin dan teknisi hanya melihat data di perangkat yang sama karena data masih disimpan di localStorage WebView. Login hanya mockup; pembayaran belum memproses uang; pilihan QRIS/e-wallet hanya label metode; lokasi GPS belum diintegrasikan; tombol peta membuka Google Maps menggunakan alamat teks. Tidak ada sinkronisasi cloud, notifikasi, keamanan peran, atau validasi pembayaran.

## Sebelum dipakai pelanggan
- Pasang backend (misalnya Supabase/Firebase) dengan autentikasi, database, dan kebijakan akses server.
- Buat role customer/admin/technician yang divalidasi server, bukan berdasarkan input aplikasi.
- Integrasikan peta dan izin lokasi Android secara eksplisit.
- Integrasikan payment gateway resmi dalam mode sandbox dahulu; jangan menyimpan data kartu.
- Simpan kredensial rahasia hanya di server; jangan masukkan service-role key ke APK.
- Tambahkan validasi, kebijakan privasi, penghapusan akun/data, audit keamanan, dan pengujian perangkat.
